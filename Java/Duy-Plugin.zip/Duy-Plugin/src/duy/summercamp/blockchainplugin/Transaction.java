package duy.summercamp.blockchainplugin;

public class Transaction {
    public String recipient_address;
    public String sender_address;
    public String value;
}
